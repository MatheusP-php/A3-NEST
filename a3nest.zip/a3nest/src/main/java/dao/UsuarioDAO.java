package dao;

import DTO.UsuarioDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class UsuarioDAO {

    Connection conn;

    public ResultSet autenticacaousuario(UsuarioDTO objUsuarioDTO) {

        conn = new Conexao().conectaBD();

        try {

            String sql = "select * from usuario where email_user = ? and senha_user = ?";

            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, objUsuarioDTO.getEmail_user());
            pstm.setString(2, objUsuarioDTO.getSenha_user());
            
            ResultSet rs = pstm.executeQuery();
            
            
            return rs;

        } catch (SQLException erro) {

            JOptionPane.showMessageDialog(null, "Usuario:" + erro);
            return null;
        }
    }
    
   

}
