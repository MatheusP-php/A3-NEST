/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import DTO.UsuarioDTO;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author fabip
 */
public class CadastroImc {
    
    
    Connection conn;
    PreparedStatement pstm;
    
    public void inserirImc(UsuarioDTO objUsuarioDTO) {
       
        
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = new Conexao().conectaBD();
            String query = "INSERT INTO tabela_imc (id_user, data_hora_inclusao, imc) VALUES (?, NOW(), ?)";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, objUsuarioDTO.getId_usuario());
            stmt.setDouble(3, objUsuarioDTO.getImc_user());
            stmt.executeUpdate();
            System.out.println("IMC inserido com sucesso.");
        } catch (SQLException e) {
             JOptionPane.showMessageDialog(null, "Cadastrar imc erro" );
        } finally {
            closeResources(conn, stmt, null);
        }
    }

    private void closeResources(Connection conn, PreparedStatement stmt, Object object) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

   

    
    
}
