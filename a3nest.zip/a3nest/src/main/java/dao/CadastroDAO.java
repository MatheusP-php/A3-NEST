/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import DTO.UsuarioDTO;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author fabip
 */
public class CadastroDAO {

    Connection conn;
    PreparedStatement pstm;

    public void cadastraruser(UsuarioDTO objUsuarioDTO) {

        String cas = "INSERT INTO usuario (nome_user, email_user, senha_user) VALUES (?,?,?);";

        conn = new Conexao().conectaBD();

        try {
            
            pstm = conn.prepareStatement(cas);
            pstm.setString(1, objUsuarioDTO.getNome_user());
            pstm.setString(2, objUsuarioDTO.getEmail_user());
            pstm.setString(3, objUsuarioDTO.getSenha_user());
            pstm.execute();
            pstm.close();
            
        } catch (Exception erro) {

            JOptionPane.showMessageDialog(null, "Cadastro erro" + erro);
        }

    }

    public ResultSet autenticacaousuario(UsuarioDTO objusuariodto) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
