/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

/**
 *
 * @author fabip
 */
public class UsuarioDTO {
     private int id_usuario;
    private String nome_user, senha_user, email_user;
    private double imc_user;

    /**
     * @return the id_usuario
     */
    public int getId_usuario() {
        return id_usuario;
    }

    /**
     * @param id_usuario the id_usuario to set
     */
    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    /**
     * @return the nome_user
     */
    public String getNome_user() {
        return nome_user;
    }

    /**
     * @param nome_user the nome_user to set
     */
    public void setNome_user(String nome_user) {
        this.nome_user = nome_user;
    }

    /**
     * @return the senha_user
     */
    public String getSenha_user() {
        return senha_user;
    }

    /**
     * @param senha_user the senha_user to set
     */
    public void setSenha_user(String senha_user) {
        this.senha_user = senha_user;
    }

    /**
     * @return the email_user
     */
    public String getEmail_user() {
        return email_user;
    }

    /**
     * @param email_user the email_user to set
     */
    public void setEmail_user(String email_user) {
        this.email_user = email_user;
    }

    /**
     * @return the imc_user
     */
    public double getImc_user() {
        return imc_user;
    }

    /**
     * @param imc_user the imc_user to set
     */
    public void setImc_user(double imc_user) {
        this.imc_user = imc_user;
    }

}
